import cv2
import numpy as np
import mediapipe as mp

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

cap = cv2.VideoCapture(0)
drawing = False
previous_finger_tip = None
drawn_image = np.zeros((480, 640, 3), np.uint8)

alpha = 0.2

with mp_hands.Hands(min_detection_confidence=0.8, min_tracking_confidence=0.8, max_num_hands=1) as hands:
    while cap.isOpened():
        success, image = cap.read()
        if not success:
            print("Ignoring empty camera frame.")
            break

        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image_rgb)

        if results.multi_hand_landmarks:
            hand_landmarks = results.multi_hand_landmarks[0]
            h, w, _ = image.shape
            finger_tip = (int(hand_landmarks.landmark[8].x * w), int(hand_landmarks.landmark[8].y * h))

            # Filtrar por posición (ajusta estos límites según tus necesidades)
            if 100 < finger_tip[0] < 500 and 100 < finger_tip[1] < 500:
                if drawing and previous_finger_tip:
                    finger_tip = (
                        int(alpha * finger_tip[0] + (1 - alpha) * previous_finger_tip[0]),
                        int(alpha * finger_tip[1] + (1 - alpha) * previous_finger_tip[1])
                    )
                    cv2.line(drawn_image, previous_finger_tip, finger_tip, (0, 255, 0), 2)

                previous_finger_tip = finger_tip

        elif drawing:
            previous_finger_tip = None  # Reiniciar la posición del dedo al dejar de dibujar

        image = cv2.addWeighted(image, 1, drawn_image, 1, 0)

        cv2.imshow("Hand Tracking", image)
        key = cv2.waitKey(1)

        if key & 0xFF == ord('q') or cv2.getWindowProperty("Hand Tracking", cv2.WND_PROP_VISIBLE) < 1:
            print("Closing the program.")
            break
        elif key == ord('d'):
            if drawing:
                print("Stopping drawing.")
                drawing = False
                drawn_image = np.zeros((480, 640, 3), np.uint8)  # Reiniciar la imagen del trazo

            else:
                print("Starting drawing.")
                drawing = True

cap.release()
cv2.destroyAllWindows()






