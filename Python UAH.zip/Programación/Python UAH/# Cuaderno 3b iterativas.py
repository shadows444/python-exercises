# Cuaderno 3b iterativas
"""
# Ejercicio 1 pedir al usuario un entero hasta que realmente lo introduzca

def pedir_entero():
    while True:
        try:
            entero = int(input("Introduzca un entero: "))
            return entero  # Devuelve el entero válido y sale de la función
        except ValueError:
            print("Eso no es un entero. Inténtelo de nuevo.")


# Llama a la función para obtener un valor entero
pedir_entero()



# Los 5 numeros siguiente a 20

a = int(input("número "))
repeticiones = int(input("Repeticiones: "))

for i in range(repeticiones):
    a+=1
    print(a)

# Bucle While (valor booleano)

# factorial de un número:

n = int(input("número: "))
factorial = 1
for i in range(1,n+1):
     factorial = factorial * i
print(factorial)

# Factorial con bucle while

n = int(input("número"))

fac = 1
i = 1

while i < n:
     i = i +1
     fac = fac *1
print(fac)


# Cuaderno 3b hacer 3-10 y 15 y 16


# pensar en un programa que te dibuje triangulos con astericos

n = int(input("número: "))


for numeros in range(1,n+1):
    #Aquí tiene que ir un bucle for pero no se que rango ni valores debe tener
        print(numeros * "*")
    #aqui tiene que ir un print de salto de línea pq cada vez que acabe la iteración con el primer for hay que dar un salto de línea


# Ejercicio 2 pedir un entero al usuario pero debe ser entre un rango definido

def entero_pedido(min,mas,msj):
     entrada = True
    while entrada == True:
        ask = int(input(f"Introduce un valor entre {min}-{mas}: "))

        if(ask < min or ask > mas):
            print("Error, no está en el rango")
          
        else:
        
            return ask
            
               
print(entero_pedido(9,12,))


# Ejercicio 3 media arítmética de números

def media():
 while True: 
  try:
    cantidad = int(input("cuantos números vas a introducir: "))
    suma = 0
  except:
    print("Error, no son valores válidos")
  
  
  else:  
    numeros = []
    for i in range(1,cantidad+1):
      ask = float(input("número: ")) 
      suma += ask
      numeros.append(ask)
    
    media = suma / cantidad
    ask = str(ask)
    ordenar = sorted(numeros)
    
        
    return media,ordenar


print(media())



# Ejercicio 4 programa que cuenta el total de números introducidos


def contador_numeros():

    contador = 0
    positivos = 0
    negativos = 0
  

    while True:
        ask = pedir_entero()
        contador = contador + 1

        if (ask > 0):
           positivos = positivos +1

        elif (ask < 0):
           negativos = negativos + 1
           
           
       
          
        if(ask == -9999):
           contador = contador -1
           negativos = negativos-1
           return f"Has introducido {contador} números de los cuales {positivos} son positivos y {negativos} son negativos"
  

print(contador_numeros())

# Ejercicio 5 programar una variante del ejercicio resuelto 3 siendo este:
# Debemos hacer que las filas pares salgan con un "@" mientras que las impares con #
def dibujar_rectangulo(a,b):     
     int,int,str -> None         
    OBJ: Dibuja en pantalla un rectángulo de dimensiones               
    a por b utilizando el símbolo como relleno        

    for i in range(a):    
        for j in range(b):  
            if(i % 2 == 0):
                print("@" , end= " ")   
            else:
                print("#",end=" ")     
        print()  
    
dibujar_rectangulo(3,5)

# Para hacer lo mismo pero con las columnas: 

def dibujar_rectangulo(a,b):     
     int,int,str -> None         
    OBJ: Dibuja en pantalla un rectángulo de dimensiones               
    a por b utilizando el símbolo como relleno     

    for i in range(a):        
        for j in range(b):         
            if((j + 1) % 2 == 0):
                
                print("@" , end= " ")   
            else:
                print("#",end=" ")     
        print()  
    
dibujar_rectangulo(3,5)



# Ejercicio 6 límites 

def calcular_terminos_serie(limit):
    suma = 0
    n = 0

    while suma <= limit:
        n += 1
        suma += 1 / n

    return n

try:
    limit = int(input("Introduce un límite positivo: "))
    if limit < 1:
        print("El límite debe ser un entero positivo.")
    else:
        n = calcular_terminos_serie(limit)
        print(f"El menor número n tal que la suma supere {limit} es {n}")
except ValueError:
    print("Ingresa un número entero positivo válido.")


# Ejercicio 7 primeras potencias 2,3,5 de un entero n

def potencias():
    potencia = [2,3,5]
    while True:
        try:
            n = int(input("valor: "))
            if(n <= 0):
                print("Error, debe ser positivo")
            else:

             print('%12s'%"BASE 2",'%10s'%"BASE 3",'%10s'%"BASE 5")
             for i in range(n+1):
                for j in potencia:
                    
                    print('%10s'%j**i,end=" ")
                    
                print('%15s'%f"EXPONENTE {i}")

             return

        except ValueError:
         print("Error")
                

potencias()
                


# Ejercicio 8 tabla de multiplicar

def tabla_multiplicar():
    
      print('%48s'%'TABLA DE MULTIPLICAR \n','%45s'%"====================")
    
      
      for i in range(1,11):
        print(i, "|",end= "\n")
        for j in range(1,11):
            print('%6s'%(i * j), end=" ")
        
        print()

tabla_multiplicar()


# Ejercicio 9 año escrito en cifras arábigas y se muestre en romano dentro del range(1,2000+1)


def romanos():
    while True:
        try:
            year = int(input("Año (1-2000): "))
            if 1 <= year <= 2000:
                break
            else:
                print("El año debe estar dentro del rango 1-2000.")
        except ValueError:
            print("Error, no es un valor válido.")

    romano = ""
    valores = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"), (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]

    for valor, letra in valores:
        while year >= valor:
            romano += letra
            year -= valor

    print(f"El año en números romanos es: {romano}")

romanos()

   
# Ejercicio 10 caja de supermercado

def cambio_monetario(pagado, cuenta):
    valores = [(500.0, "Billete"), (200.0, "Billete"), (100.0, "Billete"), (50.0, "Billete"), (20.0, "Billete"), (10.0, "Billete"), (5.0, "Billete"), (2.0, "Moneda"), (1.0, "Moneda"), (0.5, "Moneda"), (0.2, "Moneda"), (0.1, "Moneda"), (0.05, "Moneda"), (0.02, "Moneda"), (0.01, "Moneda")]
    factura = 0
    cambio = pagado - cuenta  # Redondear el cambio a 2 decimales para evitar problemas de precisión de punto flotante
    
    if cambio == 0 or cambio < 0:
        return f"No hay cambio posible"
    else:
        
     for valor, letra in valores:
        while cambio >= valor:
            factura += valor
            cambio -= valor
        return f"Su cambio es de {cambio} (debe ser dado en {letra}s)"
            


print(cambio_monetario(12, 6))



# Ejercicio 11 Menu trigonometría (Hecho en cuaderno 3a)

# Ejercicio 12 calcular la varianza poblacional 

def varianza(p, n):
    # Calcula la media de la población
    media = sum(p) / n
    
    # Inicializa la variable para la suma de los cuadrados de las diferencias
    suma_cuadrados_diferencias = 0
    
    # Calcula la suma de los cuadrados de las diferencias
    for elemento in p:
        diferencia = elemento - media
        suma_cuadrados_diferencias += diferencia ** 2
    
    # Calcula la varianza poblacional
    varianza_poblacional = suma_cuadrados_diferencias / n
    
    return varianza_poblacional

# Probador:
poblacion = [10, 20, 30, 40, 50]
n = len(poblacion)
resultado = varianza(poblacion, n)
print("Varianza poblacional:", resultado)


# Ejercicio 13 mejorar el ejercicio resuelto 4 

# Comienzo y bienvenida del ejercicio
intentos = 1 
print('Intente adivinar el símbolo oculto')    
simbolo = input('Haga su apuesta: ') 

# En caso de que falles la primera vez
while simbolo != '#':    
 simbolo = input('Ese no es el símbolo oculto. Haga su apuesta: ') 

 intentos += 1 
 if simbolo == "#":
    print(f'Por fin! Ha necesitado {intentos} intentos para adivinarlo.')  


 # Límite de intentos que puedes tener
 if intentos == 10:
    print("intentos máximo")
    simbolo = "#"


def convergencia(serie):
    factorial = 1
    numerador = 0
    denominador = 2 ** (len(serie) ** 2)

    for i in serie:
        factorial *= i
        numerador += (factorial ** 2)

    resultado = numerador / denominador
    return resultado

# Probador
serie = [1, 2, 3, 4]
resultado = convergencia(serie)
print("El resultado de la convergencia es:", resultado)


"""
# Ejercicio 15 programa que genera frases aleatorias de una lista de palabras
# las frases deben tener entre 3 y 10 palabras

import random
def palabras():
    frases = 0
    lista = ['perro','niño','nube','padre','es','esta','come','mira','ama','el','la','al','en']

    

def prueba():    

 for numero in range(8):

    print(random.randint(3, 11))



prueba()






"""

def leer_entero(msj,msj_error):
  entrada = False
  while not entrada: 
   try:
      ask = int(input("Introduce un entero: "))
      entrada = True
      return ask
   except:
      print("Error, no es un entero")


# Excepciones


# Ejercicio 4 sumar n numeros >= 2000 los menores se ignoran

def sumas_2000(n):
   suma = 0
   for valor in range(n):
    numero = leer_entero("Introduce un entero: ","Incorrecto") 
    while numero < 2000:
        numero = leer_entero("Introduce un entero: ","Incorrecto")
    suma = suma + numero  
   return suma
   

print(sumas_2000(4))
         
"""
def triangulo_izquierda(n):
 for i in range(1, n+1):
    print('*' * i)

triangulo_izquierda(6)

def triangulo_derecha(n):
 for i in range(1,n+1):
  print(" " *(n-i)+i*"*")

triangulo_derecha(6)






