# Cuaderno 4 estructuras de datos
import random 
from random import randint

# Ejercicio 1 función que sume dos listas de enteros de igual longitud y retorne otra lista con la suma de los elemetos elemento a elemento.

def suma_listas(lista1, lista2):
    
    #Comprobación de que la longitud es la misma
    if len(lista1) != len(lista2):
        resultado = False
    else:
        resultado = []
        
        # Iterar sobre cualquier lista porque tienen las mismas longitudes
        for i in range(len(lista1)):
            resultado.append(lista1[i] + lista2[i])
        
    return resultado

# Probador
lista1 = [1,2,3]
lista2 = [4,5,6]
print(suma_listas(lista1,lista2))

# Ejercicio 2 lo mismo que el primero pero las listas pueden ser desiguales y los elementos sobrantes deben añadirse en la lista resultado.

def suma_desigual(lista1, lista2):
    suma = []

    if len(lista1) < len(lista2):
        elegida = lista1
        no_elegida = lista2
    else:
        elegida = lista2
        no_elegida = lista1
                                 # Comprobación de la longitud.
    for i in range(len(elegida)):
        suma.append(elegida[i] + no_elegida[i])


    suma.extend(no_elegida[len(elegida):]) # Añade a la lista suma los valores sobrantes pertenecientes a la lista más larga.

    return suma

# Programa Probador
lista2 = [1, 2, 3, 4]
lista1 = [1, 2]
print(suma_desigual(lista1, lista2))


# Ejercicio 3 generar dos listas a partir de una.

def lista_pares(lista1):
    pares = []  # Deben estar ordenados ascendentemente.
    impares = [] # Deben estar ordenados descendentemente.
    
    for i in lista1:
        if i % 2 == 0:
            pares.append(i)
            pares.sort()     # Las dos lineas de código hechas para ordenar la lista se pueden poner fuera del for, pero de esta forma mantenemos el orden en cada interación.
        else:
            impares.append(i)
            impares.sort(reverse=True)
            
    return f"E aquí tus listas: pares: {pares}, impares: {impares}"

# Programa Probador
lista1 = [3,5,16,8]
print(lista_pares(lista1))


# Ejercicio 4 Crear una lista de enteros que nos de la media de los valores aleatorios de rango 1-20

def media_rango():
    times = int(input("Cuantos numeros deseas generar: "))
    lista = []
    for i in range(times):
        i = randint(1,21)
        lista.append(i)
    # Hasta aquí la función solo genera los números aleatorios 
    media = sum(lista) / len(lista)
    
    #Valor más alto y más bajo:
    alto = max(lista)
    menor = min(lista)
    
    return f"El valor más alto es: {alto} y el valor más bajo es: {menor}, la media de la lista: {lista} es {media}"
    
        
print(media_rango())

# Ejercicio 5 modificar notas

def calificacion_alfanumerica(calificaciones_numericas):
    
    for i in range(len(calificaciones_numericas)):
        nota = calificaciones_numericas[i]
        if nota < 5:
            calificaciones_numericas[i] = "Suspenso"
        elif 5 <= nota < 7:
            calificaciones_numericas[i] = "Aprobado"
        elif 7 <= nota < 9:
            calificaciones_numericas[i] = "Bien"
        elif 9 <= nota <= 10:
            calificaciones_numericas[i] = "Sobresaliente"
        else:
            calificaciones_numericas[i] = "Valor no válido"

# Ejemplo de uso
calificaciones_numericas = [4.5, 6.8, 7.2, 9.5, 10.0, 11.5]
calificacion_alfanumerica(calificaciones_numericas)
print(calificaciones_numericas)

# Ejercicio 6 otra vez el palíndromo 

def palindromo(palabra):
    palabra.lower()
    
    return palabra == palabra[::-1]
            
    
# Programa probador
print(palindromo("reconocer"))
print(palindromo("hola"))
print(palindromo("ana"))    

# Ejercicio 7 una función que pone la primera letra de cada palabra de una frase en mayúsculas

def palabra_mayus(frase):
    resultado = " "
    mayuscula_siguiente = True  # Indica que la siguiente letra debe ser mayúscula

    for letra in frase:
        if mayuscula_siguiente and letra.isascii():  # Verificar si la letra es un carácter ASCII
            resultado += letra.upper()
            mayuscula_siguiente = False
        else:
            resultado += letra

        if letra.isspace():  # Verificar si la letra es un espacio en blanco
            mayuscula_siguiente = True

    return resultado

# Ejemplo de uso
frase_original = "hola mundo python"
resultado = palabra_mayus(frase_original)
print(resultado)

# Ejercicio 8 Funcion que comprueba si dos cadenas de caracteres son iguales, sin compararlas completas y sin usar in.

def compara():
    
    string1 = input("palabra: ")
    string2 = input("palabra: ")
    
    string1 = string1.lower() 
    string2 = string2.lower()
    
    if string1[0] == string2[0]:
        print("Son iguales")
    else:
        print("no son iguales") 

# Programa probador y casos de prueba

#String1 = "hola", String2 = "hola"
#String1 = "Hola", String2 = "hola"
#String1 = "hola",String2 = "adiós"
compara()   

            
# Ejercicio 9 función que indica si una palabra tiene las 5 vocales

def vocales():
    palabra = input("palabra: ").lower()
    
    count = 0
    for i in "aeiou":
        if i in palabra:
            count += 1
    if count >= 5:
        print("tiene todas las vocales")
    
    else:
        print("no tiene todas las vocales")
    
            
# Programa probador

vocales()

# modificar la funcion anterior para que detecte aquellas palabras que contienen una sola vez cada vocal

def vocales():
    palabra = input("palabra: ").lower()

    vocales_vistas = ""
    count = 0

    for vocal in palabra:
        if vocal in "aeiou" and vocal not in vocales_vistas:
            vocales_vistas += vocal
            count += 1

    if count == 5:
        print("Tiene todas las vocales una vez cada una")
    else:
        print("No tiene todas las vocales o alguna está repetida")

# Programa probador
vocales()


# Ejercicio 10 codificador de letras a numeros

def codificador():
    frase = input("introduzca una frase: ")
    frase_codificada = ""
    
    for i in frase.lower():
        if i == "a":
            frase_codificada += "4" 
        elif i == "e":
            frase_codificada += "3"   
        elif i == "i":
            frase_codificada += "1"
        elif i == "o":
            frase_codificada += "0"
        elif i == "u":
            frase_codificada += "#"
        else:
            frase_codificada += i
            
    return frase_codificada

print(codificador())

# Ejercicio 11 crear una pareja de listas resultado 
#Ej: SUMAR 45 50 95. AND A B TRUE. MULT 10 20 200. Etc.  

# Entrada de texto con comandos
texto_comandos = "SUMAR 45 50 95. AND A B TRUE. MULT 10 20 200."

# Dividir el texto en frases usando el punto como separador
frases = texto_comandos.split(". ")

# Crear una lista de parejas [código, resultado]
lista_parejas = []

# Procesar cada frase
for frase in frases:
    # Dividir la frase en palabras
    palabras = frase.split()
    
    # Extraer el código y el resultado
    codigo = palabras[0]
    resultado = str(palabras[-1])
    
    # Agregar la pareja [código, resultado] a la lista
    lista_parejas.append([codigo, resultado])

# Imprimir la lista resultante
print(lista_parejas)

# Ejercicio 12 funcion que muestre los caracteres de una cadena al reves pero nunca muestra la a.

def inversa():
    frase = input("frase: ").lower()
    frase_inversa = frase[::-1]
    frase_inversa = frase_inversa.replace("a", "")
    print(frase_inversa)

inversa()

            
     
# Ejercicio 13 programa que lee palabras hasta que se introduce fin

def longitudes():
    contadores = [0] * 15
    palabra = ""

    while palabra != "fin":
        palabra = input("Palabra: ").lower()

        longitud = len(palabra)

        if palabra != "fin" and 1 <= longitud <= 15:
            contadores[longitud - 1] += 1
        elif palabra != "fin":
            print("Longitud inválida, prueba otra palabra.")

    for i, count in enumerate(contadores, start=1):
        print(f"Palabras de longitud {i}: {count}")

    return "Fin del programa"


print(longitudes())


        



        
        
    
        
   
    


print(longitudes())
        