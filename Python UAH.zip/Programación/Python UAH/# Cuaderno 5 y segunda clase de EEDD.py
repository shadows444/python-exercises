# Cuaderno 5 y segunda clase de EEDD
"""
tamaño_vector = 30

array = [0.0] * tamaño_vector



listas = [] # Las listas son mutables
tuplas = () # Las tuplas no

# Ejercicio 6 función que comprueba si una frase es un palíndromo y una palabra también

def es_palindromo(palabra):
    palabra = palabra.lower()  # Convertir la palabra a minúsculas para ignorar diferencias de mayúsculas
    return palabra == palabra[::-1]

        
# Ahora para frases también

def es_palindromo2(frase):
     frase = frase.lower()
     frase_aux = ""
     for i in range(len(frase)):
        if (frase[i] >= "a" and frase[i] <= "z") or frase[i] == "ñ": 
            frase_aux = frase_aux + frase[i]
     return es_palindromo(frase_aux)
         
    
     
         
print(es_palindromo2(input("Escriba una frase: ")))

# Ejercicio 7 poner en mayúsucula la primera letra de una palabra o frase sin usar title()

def mayus(palabra):
    resultado = ""
    for i in range(len(palabra)):
        if i == 0:
            resultado += palabra[i].upper()
        else:
            resultado += palabra[i] 
    return resultado

print(mayus(input("Introduce una frase: ")))


# Ejercicio 8 programa que compara cadenas de caracteres pero sin usar in (forma facil)

def comparador(frase,frase2):
    if frase.upper() == frase2.upper():
        print("Son iguales")
    else:print("No son iguales")
    
comparador("holA","Hola.lkasjd")


def comparador2(frase,frase2):
    if len(frase) == len(frase2):
        i = 0
        while i < len(frase):
            if frase[i] != frase2[i]:
                return "no son iguales"
            else:
                i +=1
        print("Son iguales")        
    else:
        print("No son iguales, distintas longitudes")
            
print(comparador2("hola","hora"))

# Comiendo del cuaderno 5 desde el principio

#Ejercicio 1 función que lea por teclado datos de una persona y otra que los muestre

def leer_datos():
    nombre = input("nombre: ")
    sexo = input("sexo v/h: ")
    edad = int(input("edad: "))
    
    datos = {"nombre": nombre, "sexo": sexo, "edad": edad}
    return datos

def mostrar_pantalla(datos):
    print("--Información de la persona--")
    print("nombre:",datos["nombre"])
    print("edad:", datos["edad"])
    print("sexo:",datos["sexo"])
    



# Ejercicio 2 usar los datos del ejercicio 1 para leer a 10 personas y calcular la media de la edad en general la media de sexo la cantidad de mujeres entre 13 y 16 años y la cantidad de hombres menores de 20 años.
# Ejercicio 3 ampliar el programa para que de los datos completos de el hombre y la mujer más joven.

count = 0                          # Listas para almacenar todos los valores que se nos piden.
edades = []
hombres = []
mujeres = []
edad_13_16 = []
hombres_menores = []
mujer_mas_joven = {"nombre": None, "sexo": None, "edad": float('inf')}  # Datos vacíos y edad infinita por lo que en la primera interación el primero será el menor, pero luego el segundo dato se comparará con el almacenado.
hombre_mas_joven = {"nombre": None, "sexo": None, "edad": float('inf')}

while count < 10:
    informacion = leer_datos()  #Información es = a la función leer_datos()
    count += 1 
    
    # Actualizar listas y cálculos
    edades.append(informacion["edad"])     # añadir las edades a la lista
    
    if informacion["edad"] >= 13 and informacion["edad"] <= 16 and informacion["sexo"] == "h": #Rellenar la lista de mujeres entre 13 y 16 años.
        edad_13_16.append(informacion["edad"])
        
    if informacion["sexo"] == "v":               # añadir valores a la lista hombres y comparar para hallar el hombre más joven.
        hombres.append(informacion)
        if informacion["edad"] < hombre_mas_joven["edad"]:
            hombre_mas_joven = informacion
    else:
        mujeres.append(informacion)              # Añadir valores a la lista mujeres y comparar para hallar a la mujer más joven.
        if informacion["edad"] < mujer_mas_joven["edad"]:
            mujer_mas_joven = informacion

# Cálculos finales
media = sum(edades) / len(edades)
cantidad = len(edad_13_16)
media_hombres = len(hombres) / count
media_mujeres = len(mujeres) / count
hombres_menores = len(hombres_menores)

# Resultados
print("Media de edades:", media)
print("Cantidad de personas entre 13 y 16 años:", cantidad)
print("Media de hombres:", media_hombres)
print("Media de mujeres:", media_mujeres)
print("Cantidad de hombres menores de 20 años:", hombres_menores)
print("Mujer más joven:", mujer_mas_joven)
print("Hombre más joven:", hombre_mas_joven)

# Ejercicio 4 Estructura que de soporte a los puntos 2D y programar después unas funciones para su suma y resta.
# Esa estructura será un diccionario.


x1 = float(input("x1: "))
y1 = float(input("y1: "))
x2 = float(input("x2: "))
y2 = float(input("y2: "))
    
puntos = { "x1":x1, "y1": y1, "x2": x2,"y2": y2}

suma = 0
resta = 0
calculos = {"suma": suma, "resta": resta}
    
def operaciones_puntos(operation):
    
    operation = input("operación +/-: ")
    if(operation) == "+":
        calculos["suma"]= puntos["x1"] + puntos["x2"], puntos["y1"] + puntos["y2"]
        result =  calculos["suma"]
    elif (operation) == "-":
        calculos["resta"] = puntos["x1"] - puntos["x2"], puntos["y1"] - puntos["y2"]
        result = calculos["resta"]
    else:
        print("operación no válida")  
    return result




# Ejercicio 5 función que calcula la distancia entre dos puntos.

import math
def distancia_puntos(puntos):
    distancia = math.sqrt((puntos["x2"]-puntos["x1"]) ** 2 + (puntos["y2"] - puntos["y1"]) ** 2)
    return f" La distancia entre los puntos es de: {distancia}"

print(distancia_puntos(puntos))


#Ejercicio 6 contenedor con 10 datos los cuales se van restando según el que tienen al lado, es decir [1,3,5] = [-2,-2]

#Creación de la estructura y añadir 10 valores a esa estructura
contenedor = []
new_contenedor = []
for i in range(3):
    number = int(input("valor: "))
    contenedor.append(number)
    
def resta_contenedor():
    for i in range(len(contenedor)-1):
        new_value = contenedor[i] - contenedor[i+1]
        new_contenedor.append(new_value)
        contenedor.append(new_contenedor)  
    
    return new_contenedor


print(resta_contenedor())

# Ejercicio 7 gestión de cobros en una gasolinera.

gasto_gasolina = []
gasto_productos = []
gasto_total = []

def insert_gastos():
    for i in range(10):
        cantidad_gasolina = float(input("gasto en gasolina: "))
        cantidad_tienda = float(input("gastos en tienda: "))
        gasto_gasolina.append(cantidad_gasolina)
        gasto_productos.append(cantidad_tienda)
    
    
def find_gastos_cliente():
    entrada = True
    while entrada:
        num_cliente = int(input("numero de cliente: "))
        
        if num_cliente <= 0 or num_cliente > 10:
          print("Número de cliente inválido")
          
        else:
         suma = gasto_gasolina[num_cliente -1] + gasto_productos[num_cliente - 1]
         gasto_total.append(suma)
         entrada = False
    return f" Su gasto en gasolina es de {gasto_gasolina[num_cliente -1]}, Su gasto en productos de la tienda es de {gasto_productos[num_cliente - 1]}, su gasto total {gasto_total}"
    

insert_gastos()
print(find_gastos_cliente())

# Ejercicio 8 aplicación que permite sumar dos matrices 3*4 las matrices contienen datos sobre los puntos 2D.

def crear_matriz(filas, columnas):
    matriz = []
    for i in range(filas):
        fila = []
        for j in range(columnas):
            x = float(input(f"Ingrese la coordenada x del punto en la posición ({i+1}, {j+1}): "))
            y = float(input(f"Ingrese la coordenada y del punto en la posición ({i+1}, {j+1}): "))
            fila.append((x, y))
        matriz.append(fila)
    return matriz

def sumar_matrices(matriz_a, matriz_b):
    resultado = []
    for i in range(len(matriz_a)):
        fila_resultado = []
        for j in range(len(matriz_a[0])):
            suma_puntos = (matriz_a[i][j][0] + matriz_b[i][j][0], matriz_a[i][j][1] + matriz_b[i][j][1])
            fila_resultado.append(suma_puntos)
        resultado.append(fila_resultado)
    return resultado

def mostrar_matriz(matriz):
    for fila in matriz:
        for punto in fila:
            print(f"({punto[0]}, {punto[1]})", end=" ")
        print()

# Solicitar datos para la matriz A
print("Matriz A:")
matriz_a = crear_matriz(3, 4)

# Solicitar datos para la matriz B
print("Matriz B:")
matriz_b = crear_matriz(3, 4)

# Realizar la suma de matrices
resultado = sumar_matrices(matriz_a, matriz_b)

# Mostrar el resultado
print("Resultado de matriz A + matriz B:")
mostrar_matriz(resultado)


import random 
from random import randint,randrange
#Ejercicio 9 códigos qr Programe una aplicación que genere aleatoriamente códigos QR versión 1 y los muestre por pantalla utilizando, por ejemplo, asteriscos. Nota: utilice la biblioteca random y la función randint para generar los números aleatorios

def codigos_qr(version):
    matriz = []
    for i in range(version):
        fila = []
        for j in range(version):
            pixel = random.choice([" ", "*"])
            fila.append(pixel)
        matriz.append(fila)
    return matriz
    
def mostrar_qr(matriz):
    for fila in range(len(matriz)):
        for valor in matriz[fila]:
            print(valor,end=" ")
        print()
        
mostrar_qr(matriz=codigos_qr(21))

#Ejercicio 10 Conecta 4

#Para crear el tablero usaermos una matriz 7x6 7 filas 6 columnas

def crear_tablero():
    filas = 7
    columnas = 6
    tablero = []
    user1 = input("Selecciona tu ficha # o Y: ")
    
    while user1 != "#" and user1 != "Y":
        print("no es válido, elige")
        user1 = input("Selecciona tu ficha # o Y: ")
        
    if user1 == "#":
        user2 = "Y"
    else:
        user2 = "#"
            
    for i in range(filas):
        fila = []
        for j in range(columnas):
            valores = input("Introduce tu ficha #/Y: ")
            while valores != "#" and valores != "Y":
              print("ficha no válida")
              valores = input("introduce tu ficha #/Y: ")
            fila.append(valores)
        tablero.append(fila)
    
    return tablero

def mostrar_tablero(tablero):
    for fila in range(len(tablero)):
        for valor in tablero[fila]:
            print(valor,end=" ")
        print()

def comprobacion_cuatro(tablero):
    cuatro = False
    #Primero comprobamos si alguna fila tiene 4 en raya
    for fila in tablero:
        for j in range(len(fila)-3):
            if fila[j] == fila[j+1] == fila[j+2] == fila [j+3]:
                cuatro = True
            else:
                cuatro = False
    # A continuación lo comprobaremos por columnas
    for i in range(len(tablero[0])):
        for j in range(len(tablero)-3):
            if tablero[j][i] == tablero[j+1][i] == tablero[j+2][i] == tablero[j+3][i]:
                cuatro = True
            else:
                cuatro = False
    return cuatro
                      
#Crear el tablero:
create = crear_tablero()

#Comprobar que el tablero tiene o no 4 en raya
print(comprobacion_cuatro(create))

#Mostrar el tablero
mostrar_tablero(create)

#Ejercicio 11 procedimiento que lee palabras y guarda en un diccionario su longitud hasta que se introduce la palabra fin.

def frecuencias_longitudes():
    frecuencias = {}
    palabra = ""
    while palabra.lower() != "fin" :
        palabra = input("Introduce una palabra (escribe 'fin' para finalizar): ")
        longitud = len(palabra)
        # Incrementar la frecuencia para la longitud actual en el diccionario
        frecuencias[longitud] = frecuencias.get(longitud, 0) + 1

    return(frecuencias)

print(frecuencias_longitudes())

#Ejercicio 12 función que genera dos listas y recibe un diccionario y una lista

def genera_listas(diccionario,lista):
    comparten = []
    no_comparten = []
    
    for valor in lista:
        if valor in diccionario.values():
            comparten.append(valor)
        else:
            no_comparten.append(valor)
    return f"Lista de elementos en común es: {comparten}, lista de elementos no comunes es: {no_comparten}"

#Programa probador
diccionario = {"hola":"hola","champions":4,"22":22}
lista = ["hola",19,4,22,]
print(genera_listas(diccionario,lista))

#Ejercicio 13 Programar una función que realize cambios en un diccionario.

def agregar_preferencia(diccionario,persona,preferencia):
    persona = input("persona: ")
    preferencia = input("preferencia: ")
    if persona not in diccionario["persona"]:
        print("ese nombre no existe, se añadirá ahora")
        diccionario["persona"] = persona
        new_preferencias_personales = input("preferencia personal del nuevo individuo: ")
        diccionario["preferencia"] = [new_preferencias_personales]
    
    elif preferencia not in diccionario["preferencia"]:
        print("Esa preferencia personal no se encuentra, se añadirá ahora")
        new_preferencias_personales = input("preferencia personal del nuevo individuo: ")
        diccionario["preferencia"] = [new_preferencias_personales]
    return diccionario
        
        
#Programa principal
persona = "luna"
preferencia = ["reddit"]
diccionario = {"persona":persona,"preferencia":preferencia}
print(agregar_preferencia(diccionario,persona,preferencia))

#Ejercicio 14 fútbol 

# Plantilla del FC Barcelona
plantilla_barcelona = {
    1: {'dorsal': 1, 'nombre': 'Ter Stegen'},
    3: {'dorsal': 3, 'nombre': 'Piqué'},
    5: {'dorsal': 5, 'nombre': 'Busquets'},
    9: {'dorsal': 9, 'nombre': 'Suárez'},
    10: {'dorsal': 10, 'nombre': 'Messi'},
    22: {'dorsal': 22, 'nombre': 'Ansu Fati'}
}

alineaciones_liga = {
    1: [1, 3, 5, 9, 10],
    2: [1, 3, 5, 9, 10, 22],
    3: [1, 3, 5, 9, 10, 22],
}

def agregar_jornada(numero_jornada, alineacion):
    result = False
    if numero_jornada not in alineaciones_liga:
        alineaciones_liga[numero_jornada] = alineacion
        result = True
    else:
        print(f"La jornada {numero_jornada} ya tiene una alineación: {alineacion}")
        result = False
    return result

#Determinar si participo en una jornada en base a su dorsal o nombre

def jugo_nojugo(numero_jornada,dorsal):
    if dorsal in plantilla_barcelona:
        jugador = plantilla_barcelona[dorsal]
        if jugador[dorsal] in alineaciones_liga.get(numero_jornada,[]):
            return True
    return False

#Jugador más partidos

def jugador_mas_partidos():
    conteo_partidos = {}
    for alineacion in alineaciones_liga.values():
        for dorsal in alineacion:
            conteo_partidos[dorsal] = conteo_partidos.get(dorsal, 0) + 1
    
    jugador_mas_partidos = max(conteo_partidos, key=conteo_partidos.get)
    nombre_jugador = plantilla_barcelona[jugador_mas_partidos]['nombre']
    
    return nombre_jugador, conteo_partidos[jugador_mas_partidos]


def jornadas_de_jugador(dorsal):
    jornadas = [jornada for jornada, alineacion in alineaciones_liga.items() if dorsal in alineacion]
    return jornadas
    
agregar_jornada(4, [1, 3, 5, 9, 10])
print(jugo_nojugo(10, 4))
print(jornadas_de_jugador(10))
print(jugador_mas_partidos())

#Ejercicio 15 archivos de texto.

def genera_listas(diccionario, lista):
    comparten = []
    no_comparten = []

    for valor in lista:
        if valor in diccionario.values():
            comparten.append(valor)
        else:
            no_comparten.append(valor)
    return f"Lista de elementos en común es: {comparten}, lista de elementos no comunes es: {no_comparten}"

# Programa probador
diccionario = {"hola": "hola", "champions": 4, "22": 22}
lista = ["hola", 19, 4, 22]

# Abrir el archivo en modo append ("a")
with open("C:/Users/Blanquito/Desktop/JavaEat/entrada.txt", "w") as archivo:
    # Escribir el resultado de la función genera_listas en el archivo
    archivo.write(genera_listas(diccionario, lista))

"""
#Ejercicios repaso diccionarios
lista = [9,8,7,6,5]

for i in lista:
    if lista.index(i) % 2 == 0:
        print(i)