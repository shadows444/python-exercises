# Ejercicios primer cuaderno

# Ejercicio 1: encontrar algunos valores de tipo int, str y float, y comprobar con Python su tipo

edad = 19
nombre = "Luna Tahiri"
pi = 3.14

print(type(edad))
print(type(nombre))
print(type(pi))

# Ejercicio 2: escribir un código que imprima tu edad y nombre como: "Nombre: Pedro Martín, edad: 25".
print("Nombre: " + nombre + ", " + "edad: " + str(edad) + ".")

# Ejercicio 3: Calcular el área de un cuadrado usando dos variables, una para la longitud y otra para almacenar el área.
longitud = 12
area = longitud * longitud
print(area)

# Ahora hagámoslo usando solo una variable para almacenar la longitud del lado.
longitud = 12
print(longitud * longitud)

# Ejercicio 4: escribir un programa que calcule el impuesto que un ciudadano debe pagar debido a su salario anual y la cantidad de hijos que tiene.
hijos = 4
gravable = (120000 - 600) - (60 * hijos)
impuesto_total = 1/3 * gravable
print(impuesto_total)

# Ejercicio 5: escribir un programa que, dado un momento con horas, minutos y segundos, muestre en la consola cuántos segundos han pasado desde la última medianoche y cuántos faltan hasta la próxima medianoche.
hora = int(input("Hora: "))
minutos = int(input("Minutos: "))
segundos = int(input("Segundos: "))

ultimaMedianoche = hora * 3600 + minutos * 60 + segundos
proximaMedianoche = 24 * 3600 - (hora * 3600 + minutos * 60 + segundos)
print(ultimaMedianoche)
print(proximaMedianoche)

# Ejercicio 6: flota de camiones
km = int(input("Km: "))
litrosCombustible = int(input("Cuántos litros: "))
precioCombustible = int(input("Precio por litro: "))
mantenimiento = int(input("Mantenimiento: "))

kmPorLitro = km / litrosCombustible
costoTotal = (km / kmPorLitro) * precioCombustible + mantenimiento
costoPorKm = costoTotal / km
print(costoTotal)
print(costoPorKm)

# Ejercicio 7: Python permite cambiar el tipo de elementos, probemos algunos cambios de tipo.
texto_numerico = "45"
int(texto_numerico)
# int("Hola")  # Esto da un error porque "Hola" no es un entero, por lo que no se puede convertir.
int(3.99999)  # Python redondea el número y olvida la parte decimal, así que es solo 3.
print(int(3.999) + int(4))  # Vemos que esto imprime solo 7, por lo que se demuestra que int(3.999) es solo 3, 4+3=7
int(-3.99999)  # Es lo mismo que antes, Python olvida la parte decimal, así que es solo -3.
float(34)  # En este caso, Python convierte el número en un flotante, así que es 34.0.
print(float(34) + 6)  # Como podemos ver, esto no devuelve solo 40, devuelve 40.0, por lo que se nota el cambio a flotante.
# int("diez")  # Sucede lo mismo que antes, no se puede hacer nada con este ejemplo porque "diez" no es un entero y no se puede convertir.

# Ejercicio 8: escribir un programa que calcule el área y el perímetro de un rectángulo a partir de la longitud de sus lados.
ladoLargo = int(input("Longitud del lado largo: "))
ladoCorto = int(input("Longitud del lado corto: "))

area = ladoLargo * ladoCorto
perimetro = 2 * (ladoLargo + ladoCorto)
print(area)
print(perimetro)

# Ejercicio 9: escribir un programa que, a partir de 3 números reales, calcule su suma total, su producto total y el promedio.
b = 4.15
x = 90.765
y = 44.444

producto = b * x * y
total = b + x + y
promedio = total / 3

print(str(producto) + " " + str(total) + " " + str(promedio))

# Ejercicio 10: convertir de Fahrenheit a Celsius.
temperatura = float(input("Temperatura en Fahrenheit: "))

celsius = (5.0 * temperatura - 160.0) / 9.0
print("Esta es la temperatura convertida a Celsius: " + str(celsius))

# Ejercicio 11: transcribir este programa y comentar los resultados.
a = 3/2  # Una división normal
b = 3.0 / 2  # otra división normal
c = 3 // 2  # Esta es otra división, pero usando dos // no muestra la parte decimal de la división.
print('a= ', a, 'b= ', b, 'c= ', c)

# Ejercicio 12: escribir un programa que calcule el salario neto de un empleado.
salarioNetoBasico = 2000
ventas = int(input("¿Cuántas ventas has hecho?: "))
comision = 0.03 * ventas

sinIRPF = salarioNetoBasico + comision
IRPF = 0.32 * sinIRPF

salarioNetoTotal = round(sinIRPF - IRPF, 0)

print("Salario Neto: " + str(salarioNetoTotal))

# Ejercicio 13: escribir un programa que convierta EUR a GBP.
euros = float(input("¿Cuántos euros?: "))
comision = 0.02 * euros

libras = (euros * 0.86) - comision
print("Tu cambio en libras es: " + str(libras))

# Ejercicio 14: solo copia este código y observa qué devuelve.
fruta = " ciruela "
tipo = " claudia "
print(fruta + tipo)  # Vemos que concatena las dos palabras para que estén escritas en la misma línea de código.

# Ahora intenta lo mismo pero escribe esto:
print(fruta * 3)  # Obviamente imprime la palabra ciruela tres veces.

# Ejercicio 15: escribir un código que pida 2 frutas y cree una variable llamada "fruitPlatter" que se imprima.
frutaUno = input("Fruta: ")
frutaDos = input("Fruta: ")

frutaPlato = frutaUno + " " + frutaDos
print(frutaPlato)

# Ejercicio 16: escribir un código que ordene alfabéticamente las dos palabras que el usuario introduce.
primeraPalabra, segundaPalabra = input("Primera palabra: "), input("Segunda palabra: ")
print(sorted([primeraPalabra, segundaPalabra]))

# Ejercicio 17: explicar qué significa la expresión a=a==False sabiendo que "a" es un booleano (puede ser True o False). Explicar qué podría suceder si "a" no estuviera inicializado.
a = False
a = a == False  # a = a que es True, y si a es igual a False, básicamente estamos diciendo que a es igual a a y luego estamos comparando ese a con False.
print(a)

# Ejercicio 18: finalmente, hacer la tabla de verdad de p y no q o r.
p = False
q = False
r = False

operacion = p and (not q) or r

p2 = True
q2 = False
r2 = True
operacion2 = p and (not q) or r

p = False
q = True
r = False
operacion3 = p and (not q) or r

print('%10s%10s%10s%13s' % ("p", "q", "r", "operacion"))
print("---------------------------------------------")
print('%10s%10s%10s%13s' % (p, q, r, operacion))
print('%10s%10s%10s%13s' % (p2, q2, r2, operacion2))

# Los próximos ejercicios son de internet y son solo para practicar.

# 1.2 ejercicio: escribir un programa que calcule esta operación r = ((3+2)/(2*5))^^2
r = ((3+2)/(2*5))**2  # Vi la solución y sí, está bien hecho.
print(r)

# 2.2 El siguiente es una suma, así que básicamente tengo que hacer un programa que calcule la suma de todos los números hasta el número que ha introducido el usuario.
n = int(input("Número: "))
suma_total = (n * (n + 1) / 2)
print(suma_total)

# Un programa que calcula tu IMC
peso = float(input("Peso (en kg): "))
altura = float(input("Altura en metros: "))
imc = round((peso / altura**2), 2)
print("Tu IMC es", imc)

# Un programa que muestra al usuario el resultado de una operación y también el resto.
dividendo = float(input("Dividendo: "))
divisor = float(input("Divisor: "))
resultado = round(dividendo / divisor, 2)
resto = dividendo % divisor
print('El resultado de tu operación es: ', resultado, "y el resto", resto)

# La tienda de juguetes
ventas_payasos = int(input("¿Cuántos payasos has vendido?: "))
ventas_muñecas = int(input("¿Cuántas muñecas has vendido?: "))

peso_total = ventas_payasos * 112 + ventas_muñecas * 75

print("Peso total del paquete: ", str(peso_total), "g")

# Cuenta bancaria
ahorros = float(input("Dinero: "))
impuestos = ahorros * (1 + 0.04)
print(impuestos)

# Panadería
precio = 3.49
barras_pasadas = int(input("Barras que no son del día: "))
descuento = precio * 0.60
precio_total = (precio - descuento) * barras_pasadas

print("El precio normal de la barra es: " + str(precio), "sin embargo, al no ser del día, se hace un descuento del 60%, así que el costo final es: ", round(precio_total, 2))

# Ahora vamos a empezar con algunos ejercicios de cadenas de texto.

# Un programa que pide el nombre del usuario y un número y lo imprime tantas veces como el número que el usuario introdujo.
nombre = input("Hola, ¿cuál es tu nombre?: ")
numero = int(input("¿Cuántas veces quieres que se imprima tu nombre?: "))

print((nombre + "\n") * numero)

# Ejercicio 2
nombre = str(input("Hola, ¿cuál es tu nombre?: "))

print(nombre.upper())
print(nombre.lower())
print(nombre.title())

# Un programa que cuenta cuántas letras tiene tu nombre.
nombre = input("Nombre: ")

print("Te llamas", nombre, "y tu nombre tiene: ", str(len(nombre)), "letras")

# Programa de número de teléfono
numero = input("Número con el siguiente formato: +XX-XXXXXXXX-XX")

print(numero[4:-3])

# Invertir frases
frase = input("Escribe una frase: ")

print(frase[::-1])

# Vocales en mayúscula
nombre = input("Nombre: ")

vocales = input("Introduce una vocal en minúscula: ")

print(nombre.replace(vocales, vocales.upper()))

# GMAIL
correo = input("Dime un correo electrónico: ")

print(correo[:correo.find('@')] + '@ceu.es')

# Producto
precio = (input("Precio en euros: "))

print(precio[:precio.find('.')], 'euros y', precio[precio.find('.')+1:], 'céntimos.')

# Un programa para tu fecha de nacimiento
nacimiento = input("Introduce tu fecha de nacimiento en este formato: xx/mm/aaaa: ")

print("Naciste el día: ", nacimiento[:2] + "\n" + "el mes: ", nacimiento[3:5] + "\n" + "el año: ", nacimiento[6::])

# Un programa para una tienda de comestibles
cesta = input("¿Qué hay en la cesta?: ")

print(cesta.replace(',', '\n'))

# Otro programa para una tienda de comestibles
nombre = input("Nombre del producto: ")
precio = float(input("Precio: "))
cantidad = int(input("Cantidad: "))

print(nombre, "{:06d}.{:02d}".format(int(precio), int((precio % 1) * 100)))


