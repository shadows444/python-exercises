
# Cuaderno y clase 7 hacer en casa el 5

# Ejercicio 1 programa que dado un numero finito de fechas, permita buscar una fecha por año,mes o día y la ordenación por año.
#Emplea el metodo de la busqueda binaria.

def leer_fecha():
    anio = input("año: ")
    mes = int(input("mes: "))
    dia = int(input("día: "))

    return {"dia":dia,"mes":mes,"año":anio}

Max = 3
lista = []
for i in range(Max):
    fecha = leer_fecha()
    lista.append(fecha)

print(lista)

def igual_fecha(f1,f2):
    
    return f1["año"] == f2["año"] and f1["mes"] == f2["mes"] and f1["dia"] == f2["dia"]


# Programa Principal (busqueda secuencia no binaria)
f1 = leer_fecha()
encontrado = False
i = 0
while not encontrado and i < len(lista):
    if igual_fecha(f1,lista[i]):
        encontrado = True
    i = i+1

if encontrado:
    print(encontrado)
else:
    encontrado = False
    print(encontrado)

#Cuaderno 7
#Ejercicio 1 programa que dadas unas fechas permita buscar por año, mes o día y la ordenación de estas.
#Mediante busqueda binaria ordenarlas

#Ingreso de fecha y creación de una lista vacía para poder añadir las fechas
lista = []
def ingresar_fecha():
    dia = int(input("dia: "))
    mes = int(input("mes: "))
    anio = int(input("año: "))
    

    return {"dia": dia, "mes": mes, "año": anio}

#Ejecutar la función de ingreso según la cantidad de fechas que se vayan a insertar.
def ejecutar_ingreso():
    max = int(input("¿Cuantas fechas desea añadir?: "))
    for i in range(max):
     ingreso = ingresar_fecha()
     lista.append(ingreso)



#Ordenar mediante burbuja primero años, luego meses, luego días.

#Años ordenados
def ordenar_fechas_anio(lista):
    n = len(lista)
    for valor in range(n-1):
        for numero in range(n-valor-1):
            if lista[numero]["año"] > lista[numero+1]["año"]:
                lista[numero]["año"], lista[numero+1]["año"] = lista[numero+1]["año"], lista[numero]["año"]
            else:
                lista[numero]["año"],lista[numero+1]["año"] == lista[numero]["año"],lista[numero+1]["año"]
        
    return lista

#Meses ordenados
def ordenar_fechas_meses(lista):
    n = len(lista)
    for valor in range(n-1):
        for numero in range(n-valor-1):
            if lista[numero]["mes"] > lista[numero+1]["mes"]:
                lista[numero]["mes"], lista[numero+1]["mes"] == lista[numero+1]["mes"],lista[numero]["mes"]
            else:
                lista[numero]["mes"],lista[numero+1]["mes"] == lista[numero]["mes"],lista[numero+1]["mes"]
    return lista

#Días ordenados
def ordenar_fechas_dias(lista):
    n = len(lista)
    for valor in range(n-1):
        for numero in range(n-valor-1):
            if lista[numero]["dia"] > lista[numero+1]["dia"]:
                lista[numero]["dia"], lista[numero+1]["dia"] = lista[numero+1]["dia"],lista[numero]["dia"]
            else:
                lista[numero]["dia"],lista[numero+1]["dia"] = lista[numero]["dia"],lista[numero+1]["dia"]
    return lista

#Busqueda Binaria 

#Busqueda binaria estás funciones se ejecutan después de las de ordenación la busqueda binaria debe estra ordenada pra funcionar.
#Busqueda por año
def busqueda_por_anio(lista):
    elemento = int(input("Elemento a buscar: "))
    inicio = 0
    fin = len(lista) - 1
    found = False
    
    while inicio <= fin and not found:
        medio = (inicio + fin) // 2
        valor_medio = lista[medio]["año"]
        
        if valor_medio == elemento:
            found = lista[medio]
            
        elif valor_medio < elemento:
            inicio = medio + 1
        else:
            fin = medio - 1

    return found

#Busqueda por mes
def busqueda_por_mes(lista):
    elemento = int(input("mes que quieres buscar: "))
    inicio = 0
    fin = len(lista) - 1
    found = False
    
    while inicio <= fin and not found:
        medio = (inicio + fin) // 2
        valor_medio = lista[medio]["mes"]
        if valor_medio == elemento:
            found = lista[medio]
        elif valor_medio < elemento:
            inicio = medio + 1
        else:
            fin = medio - 1
            
    return found

#Busqueda por días
def busqueda_por_dias(lista):
    elemento = int(input("día a buscar: "))
    inicio = 0
    fin = len(lista) - 1
    found = False
    
    while inicio <= fin and not found:
        medio = (inicio + fin) //2
        valor_medio = lista[medio]["dia"]
        
        if valor_medio == elemento:
            found = lista[medio]
        elif valor_medio < elemento:
            inicio = medio + 1
        else:
            fin = medio - 1
    return  found

#Creación del menú, solo llamaré a las funciones necesarias

def ejecucion_programa():
    print("Bienvenido")
    print("Pulse 1 para añadir fechas, máximo 5: ")
    print("Pulse 2 para consultar todas las fechas ordenadas por día")
    print("Pulse 3 para consultar las fechas ordenadas por mes")
    print("Pulse 4 para consultar las fechas ordenada por año")
    print("Pulse 5 para buscar una fecha por día")
    print("Pulse 6 para buscar una fecha por mes")
    print("Pulse 7 para buscar una fecha por año")
    opt = -1
    
    while opt != 0:
        opt = int(input("Inserte otra opción: "))
        if opt == 1:
            ejecutar_ingreso()
            print("¿Desea hacer algo más?")
        elif opt == 2:
            print("Aquí tiene las fechas ordenadas por día de menor a mayor: ")
            orden = ordenar_fechas_dias(lista)
            print(orden)
            print("¿Desea hacer algo más?")        
        elif opt == 3:
            print("Aquí tiene las fechas ordenadas por mes de menor a mayor: ")
            print(ordenar_fechas_meses(lista))
        elif opt == 4:
            print("Aquí tiene las fechas ordenadas por año: ")
            print(ordenar_fechas_anio(lista))
        elif opt == 5:
            ordenar_fechas_dias(lista)
            print(busqueda_por_dias(lista))
        elif opt == 6:
            ordenar_fechas_meses(lista)
            print(busqueda_por_mes(lista))
        elif opt == 7:
            ordenar_fechas_meses(lista)
            print(busqueda_por_anio(lista))
        else:
            print("Esa opción no es válida")
            
    return print(f"Ha salido del programa")
            
        
#EJecutamos la función principal :)            
ejecucion_programa()

#Ejercicio 2 ordenar 10 frases de forma descendente según la longitud de la lista, método de la burbuja
#El ejercicio 3 es añadiendo después de frase, frase = frase.split() el 2 es sin eso.
def insertar_fechas():
    lista = []
    for i in range(5):
        frase = input(f"frase{i}: ")
        frase = frase.split()
        lista.append(frase)
    return lista
  
def ordenar_frase():
    frases = insertar_fechas()
    l = len(frases)
    for posicion in range(l-1):
        for valor in range(l-posicion-1):
            if len(frases[valor]) > len(frases[valor+1]):
                frases[valor],frases[valor+1] = frases[valor+1],frases[valor]
            else:
                frases[valor],frases[valor+1] = frases[valor],frases[valor+1]
    return frases

print(ordenar_frase())
 
#Ejercicio 4 Programa de gestión del stock de una tienda de comestibles.

def dar_de_alta(lista):
    ask = int(input("¿Cuantos productos desea dar de alta?: ")) 
    while ask > 10 or ask < 0:
        print("El máxmo son 10 productos")
        ask = int(input("¿Cuántos productos desea dar de alta?: "))
        
    for i in range(ask):
     nombre = input("nombre: ").lower()
     precio = float(input("precio: "))
     stock = int(input("stock: "))
    
     diccionario = {"nombre": nombre, "precio": precio, "stock": stock}
     lista.append(diccionario)
    return lista

def busqueda_nombre(lista):
    elemento = input("¿Que desea buscar:? ").lower()
    encontrado = None
    for diccionario in lista:
      if diccionario["nombre"] == elemento:
        encontrado = f"Producto hallado: {diccionario}"
    
    # Verificamos el estado de 'encontrado' y proporcionamos el mensaje adecuado
    if encontrado is None:
        encontrado = f"El producto {elemento} no se encuentra en la lista"
    
    return encontrado

def ordenar_precio(lista):
    n = len(lista)
    
    for comprobaciones in range(n-1):
        for valor in range(n-comprobaciones-1):
            if lista[valor]["precio"] > lista[valor+1]["precio"]:
                lista[valor], lista[valor+1], = lista[valor+1],lista[valor]
            else:
                lista[valor], lista[valor+1] = lista[valor], lista[valor+1]
    return lista

def menu():
    lista = []
    print("Primero inserte 1 para dar de alta uno o varios producto")
    print("Ingrese 2 para buscar un producto")
    print("ingrese 3 para ver los productos ordenados por precio")
    opt = -1
    while opt !=0:
        opt = int(input("¿que desea hacer?: "))
        if opt == 1:
            dar_de_alta(lista)
        elif opt == 2:
            print(busqueda_nombre(lista))
        elif opt == 3:
            print("Esta es la lista de productos ordenada por precio: ")
            print(ordenar_precio(lista))
        elif opt > 3 or opt <0:
            print("Esa opción no es válida")
        else:
            return f"Saliendo del programa"
print(menu())

#Ejercicio 5 programa de gestión de notas de los alumnos

def ingresar_notas(lista):
    for i in range(0,19):
        nombre = input("nombre: ").lower()
        nota = float(input("nota: "))
        diccionario = {"nombre": nombre, "nota": nota}
        lista.append(diccionario)
    return lista

def modificar_nota(lista):
    
     nombre_buscado = input("¿Nombre del alumno al que desea modificar la nota?: ").lower()
     found = False
    
     for alumno in lista:
      if alumno["nombre"] == nombre_buscado:
        found = True
        nueva_nota = float(input("Introduzca la nueva nota: "))
        alumno["nota"] = nueva_nota
            
     if not found:
        print("Ese alumno no se encuentra en la lista.")
        
     return lista

def ordenar_nombres(lista):
    
    n = len(lista)
    for posicion in range(n-1):
        for valor in range(n-posicion-1):
            if lista[valor]["nombre"] > lista[valor+1]["nombre"]:
                lista[valor],lista[valor+1] = lista[valor+1],lista[valor]
                lista_ord = lista[valor],lista[valor+1]
            else:
                lista[valor],lista[valor+1] = lista[valor],lista[valor+1]
                lista_ord = lista[valor],lista[valor+1]
    return lista_ord

    
def busqueda_nota(lista):
    ordenar_nombres(lista)
    nombre_buscado = input("nombre del alumno a consultar: ").lower()
    inicio = 0
    fin = len(lista)-1
    found = False
    valor_retorno = "No se encuentra ese alumno"
    while inicio <= fin and not found:
        medio = (inicio + fin) // 2
        valor_medio = lista[medio]["nombre"]
        if valor_medio == nombre_buscado:
            found = True
            valor_retorno = lista[medio]
        elif valor_medio < nombre_buscado:
            inicio = medio + 1
        else:
            fin = medio - 1
    return valor_retorno

def media_notas(lista):
    n = len(lista)
    notas = []
    
    # Se cambia la posición de estas líneas para evitar errores
    suma = sum(notas)
    i = len(notas)
    
    media_aprobados = input("¿Qué media quieres calcular? aprobados/general: ").lower()
    
    for diccionario in lista:
        valor = diccionario["nota"]
        
        if media_aprobados == "general":
            notas.append(valor)
        elif media_aprobados == "aprobados":
            if valor >= 5:
                notas.append(valor)

    if len(notas) == 0:
        media =  "No hay notas para calcular la media."
    
    media = sum(notas) / len(notas)
    return f"La media de las notas de la clase es: {media}"

def mejor_nota(lista):
    n = len(lista)
    
    for posicion in range(n-1):
        for valor in range(n-posicion-1):
            if lista[valor]["nota"] > lista[valor+1]["nota"]:
                lista[valor]["nombre"], lista[valor]["nota"],lista[valor+1]["nombre"],lista[valor+1]["nota"] = lista[valor+1]["nombre"],lista[valor+1]["nota"],lista[valor]["nombre"],lista[valor]["nota"]
            else:
                lista[valor]["nombre"], lista[valor]["nota"],lista[valor+1]["nombre"],lista[valor+1]["nota"] = lista[valor]["nombre"], lista[valor]["nota"],lista[valor+1]["nombre"],lista[valor+1]["nota"]
    return f"La mejor nota corresponde a: {lista[-1]}"

def peor_nota(lista):
    n = len(lista)
    
    for posicion in range(n-1):
        for valor in range(n-posicion-1):
            if lista[valor]["nota"] > lista[valor+1]["nota"]:
                lista[valor]["nombre"],lista[valor]["nota"], lista[valor+1]["nombre"],lista[valor+1]["nota"] = lista[valor+1]["nombre"],lista[valor+1]["nota"],lista[valor]["nombre"],lista[valor]["nota"]
            else:
                lista[valor]["nombre"],lista[valor]["nota"],lista[valor+1]["nombre"],lista[valor+1]["nota"] = lista[valor]["nombre"],lista[valor]["nota"],lista[valor+1]["nombre"],lista[valor+1]["nota"]

    return f"La peor nota corresponde a: {lista[0]}"

def menu():
    lista = []
    print("Bienvenido a la consulta de alumnos")
    print("Primero ingrese datos de alumnos, máximo 20")
    ingresar_notas(lista)
    
    print("Ingrese 1 par ingresar otros datos de alumnos, máximo 20")
    print("Ingrese 2 para modificar la nota de un alumno")
    print("Ingrese 3 para consultar la información de un alumno")
    print("Ingrese 4 para hallar la media de todas las notas o solo las aprobadas")
    print("Ingrese 5 para hallar la mejor nota")
    print("Ingrese 6 para hallar la peor nota")
    print("Ingrese 0 para salir de la aplicación de consulta")
    
    opt = -2

    while opt!=0:
        opt = int(input("¿Qué consulta desea realizar tras haber insertado los datos?: "))
        if opt == 1:
            ingresar_notas(lista)
        elif opt == 2:
            lista = modificar_nota(lista)
        elif opt == 3:
            print(busqueda_nota(lista))
        elif opt == 4:
            print(media_notas(lista))
        elif opt == 5:
            print(mejor_nota(lista))
        elif opt == 6:
            print(peor_nota(lista))
        elif 6 > opt < 1:
            print("Esa acción no es válida")
        else:
            print("Saliendo del programa")
       
    
        
    
menu()
    
            
        
    
    
    
            
        
        
            





    
    
      
  

    