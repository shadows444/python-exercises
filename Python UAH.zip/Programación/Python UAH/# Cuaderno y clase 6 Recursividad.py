# Programar un procedimiento recursivo que compruebe si un cierto número se encuentra o no en una lista

def buscar_numero(lista, numero):
    if len(lista) == 1:
       resultado = lista[0] == numero
    else:
      if lista[0] == numero:
          resultado = True
      else:
             
       resultado = buscar_numero(lista[1:len(lista)],numero) 
    return resultado  

# Probador:
mi_lista = [1, 2, 3, 4, 5]
numero_buscado = 300

if buscar_numero(mi_lista, numero_buscado):
    print(f"El número {numero_buscado} está en la lista.")
else:
    print(f"El número {numero_buscado} no está en la lista.")


#IMPORTANTE
# Combinatorio de n sobre m

def combinatorio(n,m):
   #int,int-->  int 
    if m == 0 or m == n:
        resultado = 1
    else: 
        resultado = combinatorio(n-1,m) + combinatorio(n-1,m-1)
    return resultado

try:
 n = int(input("n: "))
 m = int(input("m: "))
except:
    print("No es un entero")
else:
    
 if n < 0 or m < 0 or n < m:
    print("No es válido")
 else:
    
  print(combinatorio(n,m))

#Cuaderno 6
#Ejercicio 1 
# suma longitud de una lista

def suma(palabra):
    if len(palabra) == 1:
        long = len(palabra)
    else:
        long = len(palabra[:1]) + suma((palabra[1:]))
        
    return long

print(suma("holaa"))

#Ejercicio 1 Programar un procedimiento recursivo que permita saber si un numero está en una lista o no.

def esta_en_lista(n,lista):
    if n not in lista:
        busqueda = ("el elemento no se encuentra en la lista")    
    elif lista[0] == n:
        busqueda = n
    else:
        busqueda = esta_en_lista(n,lista[1:])
    
    return busqueda

print(esta_en_lista(2,[1,4,6,8,8,2]))

# Ejercicio 2 multiplicación recursiva
def multiplicar_recursiva(n,n2):
    if n2 == 1:
        calculo = n
    else:
        calculo = n + multiplicar_recursiva(n,n2-1)
    return calculo

print(multiplicar_recursiva(2,5))

#Ejercicio 3 división entera recursividad

def division(n,n2):
    if n < n2:
        calculo = 0
    else:
        calculo = 1 + division(n-n2,n2)
    return calculo

print(division(15,3)) 

# Ejercicio 4 Fibonacci

def fibonacci(n):
    if n == 0:
        calculo = n
    elif n == 1:
        calculo = n
    else:
        calculo = fibonacci(n-1) + fibonacci(n-2)
    return calculo

print(fibonacci(3))

#Ejercicio 5 palabra inversa

def inversa_recursiva(palabra):
    if len(palabra) == 1:
        inversa = palabra[0]
    else:
        inversa = palabra[-1] + inversa_recursiva(palabra[:-1])
    return inversa

print(inversa_recursiva("hola"))

#Ejercicio 6 contador de dígitos de un número

def contador(n):
    n = str(n) # Para poder iterar y recorrer los dígitos lo convertimos a string
    #Caso base
    if len(n) == 1:
        cantidad = 1
    else:                              #Puedes usar uno o len(n[0])
        cantidad = len(n[0]) + contador(n[1:]) #Recursividad coge el primer elemento en cada iteración.
    return cantidad

print(contador(9988888))

#Ejercicio 7 conversor de decimal a binario

def binario(n):
    if n == 0:
        num_bn = n
    else:
        num_bn = binario(n//2)
        print(n % 2, end="")
    return num_bn

binario(8)

#Ejercicio 8 calcular la suma de los números pares desde 0 hasta n

def suma_pares(n):
    if n % 2 !=0:
        n = n-1
    if n == 0:
        suma = 0
    else:
        suma = n + suma_pares(n-2)
    return suma        
print(suma_pares(8))

#Ejercicio 9 suma de edades de todos los elementos de una lista de alumnos.
def suma_edades_alumnos(lista_alumnos, indice=0):
    if indice == len(lista_alumnos):
        suma_total = 0
    edad_actual = lista_alumnos[indice]["edad"]
    suma_resto = suma_edades_alumnos(lista_alumnos, indice + 1)
    suma_total = edad_actual + suma_resto

    return suma_total

# Ejemplo de lista de alumnos
lista_de_alumnos = [
    {"nombre": "Juan", "edad": 20, "titulacion": "Ingeniería Informática"},
    {"nombre": "María", "edad": 22, "titulacion": "Matemáticas"},
    {"nombre": "Carlos", "edad": 21, "titulacion": "Biología"}
]

resultado = suma_edades_alumnos(lista_de_alumnos)

print(f"La suma de las edades de los alumnos es: {resultado}")
# Ejercicio 10 dado un numero y una base menor de 10 convertir el numero dado a esa base.
def decimal_a_base_n(numero, base):
    if numero < 0 or base < 2 or base > 9:
        return "Entrada no válida"

    if numero < base:
        return str(numero)
    else:
        return decimal_a_base_n(numero // base, base) + str(numero % base)

# Probador
numero_decimal = int(input("número en base decimal: "))
base_destino = int(input("Ingrese la base destino (entre 2 y 9): "))

resultado = decimal_a_base_n(numero_decimal, base_destino)

print(f"El número {numero_decimal} en base {base_destino} es: {resultado}")

    