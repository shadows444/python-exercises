# Cuaderno 2 modularidad
import math


# Ejercicio 1 función fuerza

def fuerza(masa,aceleracion):
   
   return masa*aceleracion


print(fuerza(5,4))

# Ejercicio 2 Barn

def metro_barn(metros):
   
   return  round(metros * 10**28)

print(metro_barn(6),"Barns") 

def barn_metro(barn):
   return round(barn / 10**28)


print(barn_metro(6),"metro cuadrado")

# Ejercicio 3 Tasa de Interés Efectivo Anual

def tiea(m,tna):
   return ((1+tna/m) ** m-1) * 100

print(tiea(2,15), "%")

# Ejercicio 4 reloj de medianoche

def medianoche(hora,min,sec):

   if hora > 24 or hora < 0:
      return "ERROR, la hora debe estar entre 0 y 24"
   elif min > 59 or min < 0:
      return "ERROR, los minutos deben estar entre 59 y 0"
   elif sec > 59 or sec < 0:
      return "ERROR, los segundos deben estar entre 59 y 0"
   else:
       return "Han pasado" +  " " + str((hora*3600) + (min*60) + sec) + " " + "segundos desde la última medianoche"

  


print(medianoche(12,29,45))

# ejercicio 5 punto sobre circunferencia

def punto(x, y):
    circunferencia = x**2 + y**2
    
    if circunferencia >= 1000:
       print("El punto no está sobre la circunferencia")
    else:
       print("El punto está sobre la circunferencia")
    
    return circunferencia

# Programa principal
print(punto(5, 5))

# Ejercicio 6 numero de pintas de un líquido

pintas_valor = 473.176473
def pintas(ml):
   conversion = round(ml * pintas_valor,2)
   return f"{ml} mililitros equivalen a {conversion} pintas"

## Programa principal
ml = float(input("Ingese la cantidad de ml que quiere convertir a pintas: "))
print(pintas(ml))

# Ejercicio 7 temperatura en grados y en fahrenheit

def grados_a_fahrenheit(grados):
   fahrenheit = (9 * grados) / 5 + 32
   return f"{grados} grados centígrados equivalen a {fahrenheit} grados Fahrenheit."

def grados_a_kelvin(grados):
   kelvin = grados + 273.15
   return f"{grados} grados centígrados equivalen a {kelvin} Kelvin."

# Programa principal
grados = float(input("Ingresa la temperatura en grados centígrados: "))

print(grados_a_fahrenheit(grados))
print(grados_a_kelvin(grados))

# Ejercicio 8 distancia entre puntos

def distancia(x1,y1,z1,x2,y2,z2):
   formula = math.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)

   return f"la distancia entre {x1,y1,z1} y {x2,y2,z2} es {formula}"

##Programa principal
print(distancia(2,4,6,5,7,8))

# Ejercicio 9 números complejos

a = float(input("número: "))
b = float(input("número: "))
c = float(input("número: "))
d = float(input("número: "))

def suma_compleja(a,b,c,d):
   real = a+c
   imaginaria = b+d
   
   return real, imaginaria

def resta_complejos(a,b,c,d):
   real = a-c
   imaginaria = b-d

   return real, imaginaria

def multiplicacion_complejos(a,b,c,d):
   real = a*c
   imaginaria = b*c

   return real, imaginaria

def division_complejos(a,b,c,d):
   real = a/c
   imaginaria = b/d

   return real, imaginaria

print(suma_compleja(a,b,c,d),resta_complejos(a,b,c,d),multiplicacion_complejos(a,b,c,d),division_complejos(a,b,c,d))

# Ejercicio 10 subprograma áreas 

def area_circulo(r):
   """ float-->float
   OBJ:Calcula el área de un triángulo
   PRE:Radio>=0"""
   return((math.pi) * (r**2))

def ask_radio():
   """float-->float
   OBJ:Pide un radio al usuario
   PRE:Radio>0"""
   r = float(input("radio: "))
   if(r<0):
      print("ERROR, EL VALOR DEL RADIO NO ES VÁLIDO")   
   else:
      resultado = area_circulo(r)
      print(f"El área del criculo es: {resultado}")

def area_cuadrado(largo,ancho):
   """ float-->float
   OBJ: Calcula el área de un rectángulo
   PRE:largo y ancho>=0"""
   return (largo*ancho)

def ask_largo_ancho():
   """float-->float
   OBJ:Pide un largo y un ancho del rectángulo
   PRE:Largo y ancho>=0"""
   largo=float(input("Largo: "))
   ancho=float(input("Ancho: "))

   if(largo<=0 or ancho<=0):
      print("ERROR, LOS VALORES DE ANCHO Y LARGO NO SON VÁLIDOS")
   else:
      resultado = area_cuadrado(largo,ancho)
      print(f"El área del rectángulo es: {resultado}")



def area_triángulo(base, altura):
    """ float, float --> float
    OBJ: Calcula el área de un triángulo
    PRE: base y altura >= 0 """
    return (base * altura) / 2

def ask_base_altura():
    """ None --> None
    OBJ: Pide una base y una altura del triángulo y calcula el área.
    PRE: - """
    base = float(input("Base: "))
    altura = float(input("Altura: "))
    
    if base <= 0 or altura <= 0:
        print("ERROR, LOS VALORES DE BASE Y ALTURA NO SON VÁLIDOS")
    else:
        resultado = area_triángulo(base, altura)
        print(f"El área del triángulo es: {resultado}")

#· Programa principal
ask_base_altura()
ask_largo_ancho()
ask_radio()

# Ejercicio 11 calendario gregoriano

def es_bisiesto(anno):

 return (anno % 4 == 0 and anno % 100 != 0) or (anno % 400 == 0)

## Programa principal

anno = int(input("año: "))
print(f"¿El año {anno} es bisiesto?: {es_bisiesto(anno)}")

# Ejercicio 12 notas parciales

def round_nota(nota):
   """float-->float
   OBJ:Convertir notas decimales a entero o medios
   Pre: Notas>=0"""
   
   return round(nota * 2) / 2

nota = float(input("nota: "))
print(f"La nota {nota} redondeada es {round(nota)}")

# Ejercicio 13 días horas minutos y segundos que hay en una cantidad de segundos (despreciando las fracciones de segundos)

def segundos_en_horas_minutos():
   """ integer--->float or integer
   OBJ:Cantidad de horas y minutos en una cantidad de segundos
   PRE:Segundos>=0"""
   segundos = int(input("segundos: "))
   horas = segundos / 3600
   minutos = (segundos % 3600) / 60

   print(f"Hay {horas} horas y {minutos} minutos en {segundos} segundos")

segundos_en_horas_minutos()

# Ejercicio 14 Ejecutar código en python tutor

# Ejercicio 15 Flexibilizar el código del ejercicio 14

def centrarRotulo(rotulo, signo='=', ancho=72):
    """string, string, int --> None
    OBJ: centra rótulo, subrayado con el signo especificado, en una ventana de ancho dado
    """
    tam = len(rotulo)
    lado = (ancho - tam) // 2
    print()
    print(' ' * lado + rotulo)
    print(' ' * lado + signo * tam, end='\n')

# Probador
frase = 'Don Quijote de la Mancha'
centrarRotulo(frase)  # Usando el valor predeterminado '=' y ancho 72
centrarRotulo('Cervantes', '+', 80)  # Especificando '+' como signo y ancho 80
rotulo = 'El famoso hidalgo don Quijote de la Mancha'
centrarRotulo(rotulo, '*', 100)  # Especificando '*' como signo y ancho 100
centrarRotulo("Ajustando el contenido", '-', 60)  # Especificando '-' como signo y ancho 60

# Ejercicio 16 subprograma ley de los gases ideales

p = float(input("presión: "))
n = float(input("número de moles: "))
r = 0.082 # Cte 
t = float(input("temperatura: "))

def gases_ideales(p, n, r, t):
    resultado = (n * r * t) / p
    print(f"{resultado} litros de volumen")

# Ejercicio 17 gas en estado ideal

def condiciones_ideales(p=1, t=0):
    return p == 1 and t == 0

"""
if condiciones_ideales(p, t):
    print("Es un gas ideal")
else:
    print("No es un gas ideal")

# Ejercicio 18 calcular el volumen de un gas ideal (combinar primera función con la segunda)

if condiciones_ideales(p, t):
    gases_ideales(p, n, r, t)
else:
    print("No se puede calcular el volumen porque no es un gas ideal")
"""
# Ejercicio 19 implementar valores por defecto

gases_ideales(condiciones_ideales(),n,r,condiciones_ideales())

# Ejercicio 20 crear bibliotecas


import bib_conversiones

print(bib_conversiones.metro_barn(metros=6))




































