def suma_complejos(a, b, c, d):
    # Suma de números complejos: (a+bi) + (c+di) = (a+c) + (b+d)i
    parte_real = a + c
    parte_imaginaria = b + d
    return (parte_real, parte_imaginaria)

def resta_complejos(a, b, c, d):
    # Resta de números complejos: (a+bi) - (c+di) = (a-c) + (b-d)i
    parte_real = a - c
    parte_imaginaria = b - d
    return (parte_real, parte_imaginaria)

def producto_complejos(a, b, c, d):
    # Producto de números complejos: (a+bi) * (c+di) = (ac-bd) + (ad+bc)i
    parte_real = (a * c) - (b * d)
    parte_imaginaria = (a * d) + (b * c)
    return (parte_real, parte_imaginaria)

def division_complejos(a, b, c, d):
    # División de números complejos: (a+bi) / (c+di) = ((ac+bd)/(c^2+d^2)) + ((bc-ad)/(c^2+d^2))i
    denominador = (c**2) + (d**2)
    parte_real = ((a * c) + (b * d)) / denominador
    parte_imaginaria = ((b * c) - (a * d)) / denominador
    return (parte_real, parte_imaginaria)

# Probadores para verificar el funcionamiento de las operaciones
def probar_operaciones():
    num1 = (3, 4)  # Representa 3 + 4i
    num2 = (1, 2)  # Representa 1 + 2i

    # Suma
    resultado_suma = suma_complejos(num1[0], num1[1], num2[0], num2[1])
    print("Suma:", resultado_suma)  # Debería mostrar (4, 6)

    # Resta
    resultado_resta = resta_complejos(num1[0], num1[1], num2[0], num2[1])
    print("Resta:", resultado_resta)  # Debería mostrar (2, 2)

    # Producto
    resultado_producto = producto_complejos(num1[0], num1[1], num2[0], num2[1])
    print("Producto:", resultado_producto)  # Debería mostrar (-5, 10)

    # División
    resultado_division = division_complejos(num1[0], num1[1], num2[0], num2[1])
    print("División:", resultado_division)  # Debería mostrar (2.0, 0.0)

# Llamamos a la función de prueba
probar_operaciones()
