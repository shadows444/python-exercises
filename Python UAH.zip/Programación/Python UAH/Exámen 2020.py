# Ejercicio de práctica bucles

# Exámen 2020 gic
"""
# Tragaperras
import random

def tirada():
    for i in range(3):
        i = random.randint(1,6)
        print(i)


tirada()

lista = [1,2,3,4]
for i in range(1,5):
    for j in lista:
        print(j,end=" ")
      


    print()
    


# Pirámide de números

n = int(input("número: "))

for fila in range(1,n+1):
     for j in range(0,fila):
      print(fila*1, end=" ")
     print()

# Triángulo de asteriscos

n = int(input("altura del triángulo: "))

for i in range(1,n+1):
    for j in range(n-i):
        print(" ", end="")
    print("*" * i)


# triángulo de asteriscos equilatero

n = int(input("altura: "))

for i in range(1,n+1):
    for j in range(n-i):
        print(" ", end="")
    print("*" * (2*i-1))




n = int(input("altura: "))

for i in range(n,-1,-1):
    for j in range(n-i):
        print(" " , end="")
    print("*" * i)



n = int(input("altura: "))

for i in range(1,n+1):

    for j in range(n-i):
        print(" ", end="")
    print("*" * (2*i-1))

    
    for k in range(n,0,-1):
        print(" " , end="")
        for x in range(0,n-1):
            print(" ", end="")
        print("*" * (2*i-1))
    print("*" * (2*i-1))


n = int(input("altura: "))


for i in range(1,n+1):

    for j in range(n-i):
        print(" ", end="")
    print("*" * (2*i-1))


for i in range(n,0,-1):
    for j in range(0,n-i):
        print(" ", end="")
    print("*" * (2*i-1))

import random

def tirada():
    a = random.randint(1, 6)
    b = random.randint(1, 6)
    c = random.randint(1, 6)
    return a,b,c




def premio(a, b, c):
    if a == b == c:
        monedas = 5
    elif a == b or a == c or b == c:
        monedas = 2
    else:
        monedas = 0
    return monedas



# Programa principal


MONEDAS_INICIALES = 3
monedas = MONEDAS_INICIALES
entrada = True

while entrada == True:
 
    t1,t2,t3 = tirada()
    print(f'Tirada: {t1}, {t2}, {t3}')
    monedas_ganadas = premio(t1,t2,t3)
    monedas += monedas_ganadas 
    print(f'Ha ganado {monedas_ganadas} monedas. Ahora tiene {monedas} monedas.')
 
    ask = input("desea volver a jugar? s/n: ")
    if(ask.lower()=="s"):
     entrada = True
    else:
     entrada = False
     print(f"Gracias por jugar, ha ganado {monedas} monedas")

"""

def es_cadena_binaria(cadena):
    """PRE: str--->str,str
       OBJ: Indica si una cadena de caracteres está compuesta únicamente por ceros y unos y tiene una longitud de 7 caracteres.
       También devuelve la cantidad de unos y ceros en la cadena."""
    
    cadena = str(cadena)  
    suma_de_unos = 0
    suma_de_ceros = 0
    binario = True  # Suponemos que la cadena es binaria

    for i in cadena:
        if i != "0" and i != "1":
            binario = False
            return f"No es válido, solo valores binarios, intenta de nuevo"  # Si se encuentra un carácter no válido, establece binario en False

        if i == "1":
            suma_de_unos += 1
        elif i == "0":
            suma_de_ceros += 1

    if len(cadena) == 7 and binario:
        return f"Es una cadena binaria válida de 7 caracteres. Contiene {suma_de_unos} unos y {suma_de_ceros} ceros."
    elif len(cadena) != 7:
        return f"No tiene 7 caracteres: {len(cadena)} caracteres.Contiene {suma_de_unos} unos y {suma_de_ceros} ceros"
    else:
        return "No es válido, inserta valores binarios, prueba de nuevo"



# Ejercicio 2 
def leer_cadena_binaria():
   ask = input("numero binario: ")
   while len(ask)<7 or len(ask) > 7:
       print("No es válido, debe tener exacatmente 7 dígitos")
       ask = input("número binario: ")
   
   print(es_cadena_binaria(ask))

# Ejercicio 3

def tiene_paridad_par(cadena_bin):
    """ str --> bool
    OBJ: Indica si la cadena binaria tiene un numero par de unos.
    PRE: cadena_bin debe estar compuesta unicamente por 0s y 1s y tener long. 7
    """
    cont_unos = 0
    for digito in cadena_bin:
        if digito == '1':
            cont_unos += 1
    
    if cont_unos % 2 == 0:
        paridad = True
    else:
        paridad = False
    return paridad

    
# Prueba de valor binario válido desde insertar como input

print(es_cadena_binaria("98")) # No lo acepta
print(es_cadena_binaria("01101"))
leer_cadena_binaria()
print("paridad =", tiene_paridad_par("011000110011"))











        
