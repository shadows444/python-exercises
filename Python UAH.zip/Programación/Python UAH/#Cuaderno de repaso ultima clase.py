#Cuaderno de repaso ultima clase

#Ejercicio 4 cuaderno 7 con modificaciones del profe
#Programa para gestionar los datos de stock de una tienda de comestibles.

#Función para la opción 1 del menú.

lista_productos = []
def get_producto():
    nombre = input("nombre: ")
    precio =float(input("precio: "))
    stock = int(input("stock: "))
    producto = {"nombre": nombre, "precio": precio, "stock": stock}
    
    return producto

#Funciones para la opción 2 del menú.
def cargar_lista():
    for i in range(5):
       p = get_producto()
       lista_productos.append(p)
    return lista_productos

def escribir_lista(lista_productos):
    for i in range(5):
        print(lista_productos[i]["nombre"], lista_productos[i]["precio"], lista_productos[i]["stock"])
        

    
#3 del menú ordenar por busqueda binaria y ordenar por burbuja.
#Primero ordenar por burbuja.
              
def ordenar_nombre():
    
    
       

    
    
    





    
    
     