# Cuaderno 3 estructuras de control y excepciones

# Ejercicio 1 importe de las compras
"""
try:
 importe = float(input("importe: "))
 tipo_pago = input("¿va a pagar al contado?: ")

except: 
 print("ERROR los valores introducidos no son válidos")
else:
 total = importe
 if importe > 100:
   if tipo_pago.lower() == "no":
    total = importe * 0.98  
   elif tipo_pago.lower() == "si": 
    total = importe * 0.95
print(f"Tras aplicar un descuento correspondiente el total a pagar es de {total}")

# Ejercicio 2 convertir horas en formato de 24 horas a formato de 12 horas

try:
 hour = int(input("Hora en formato 24 horas: "))
 minutes = int(input("Minutos: "))
except:
  print("Error las horas no son válidas")
else:
 if(hour > 24 or minutes > 60):
  print("Error, las horas no son válidas")
 elif (hour > 12):
  hour_doce = round(hour - 12)
  print(f"{hour_doce} horas {round(minutes)} minutos")
 else:
  print(f"{round(hour)} horas y {round(minutes)} minutos")


# Ejercicio 3 función validar entero

def validar_entero():
    try:
     entero = int(input("Inserte un entero: "))
     es_entero = True
    except:
       es_entero = False

    print(es_entero)

validar_entero()

# Ejercicio 4 Reprogramar el ejercicio 2 con lo hecho en el 3 

def formato_doce():
    try:
     hour = int(input("Hora en formato 24 horas: "))
     minutes = int(input("Minutos: "))
    except:
     print("Error las horas no son válidas")
    if(hour > 24 or minutes > 60):
     print("Error, las horas no son válidas")
    elif (hour > 12):
      hour_doce = round(hour - 12)
      print(f"Son las {hour_doce} horas {round(minutes)} minutos")
    else:
      print(f"Son las {round(hour)} horas y {round(minutes)} minutos")


formato_doce()


# ejercicio añadido imprimir una matriz
caso_prueba = ([12.2,12.2,12.2],[1.0,2.0,0.33],[19.53,4.34,3.24],[8.0,19.0,1.0])

for subitem in caso_prueba:
    print(" ")
    for item in subitem:
        print('%6s'%item,end=" ")


# Ejercicio 5 sistema de calificación de una universidad

def calificacion():
  correcto = False
  while not correto:
    try:
        calificacion = float(input(("Nota: ")))
        correcto = True
    except:
        print("Error, no es una nota válida")
        
    if calificacion >= 8.5:
        nota = "A"
    elif calificacion >= 6.5:
        nota = "B"
    elif calificacion >= 5:
        nota = "C"
    elif calificacion >= 3.5:
        nota = "D"
    else:
        nota = "F"
    return nota

calificacion()

# Ejercicio 6 Algoritmo que pida 3 números y los ordene

def ordenar():
 try:
    numero_a = int(input("Primer número: "))
    numero_b = int(input("Segundo número: "))
    numero_c = int(input("Tercer número: "))
 except: 
    print("Los valores insertados no son válidos")

 if numero_a > numero_b  and numero_a > numero_c and numero_b > numero_c:
      message = (f"{numero_a} > {numero_b} > {numero_c}")
 elif numero_a > numero_b and numero_a > numero_c and numero_b < numero_c:
      message = (f"{numero_a} > {numero_c} > {numero_b} ")
 elif numero_a < numero_b and numero_b > numero_c and numero_c > numero_a:
      message = (f"{numero_b} > {numero_c} > {numero_a}")
 elif numero_a < numero_b and numero_b > numero_c  and numero_c < numero_a:
      message = (f"{numero_b} > {numero_a} > {numero_c}")
 elif numero_c > numero_b and numero_c > numero_a and numero_b > numero_a:
      message = (f"{numero_c} > {numero_b} > {numero_a}")
 elif numero_c > numero_b and numero_c > numero_a and numero_b < numero_a:
     message = (f"{numero_c} > {numero_a} > {numero_b}")
 else:
    message = f"Varios números son iguales"
 return message


print(ordenar())

# Ejercicio 7 programa que determine si algo es un carácter o no

def es_vocal():

    char = input("carácter: ")    
    message = "Es vocal"
    if( char.lower() == "a"):
        message = message
    elif char.lower() == "e":
        message = message
    elif char.lower() == "i":
        message = message
    elif char.lower == "o":
        message = message
    elif char.lower == "u":
        message = message
    else:
        message = "No es una vocal"
    return message

print(es_vocal())

# Este mismo ejercicio pero usando or (personalmente este me gusta más)

def vocal_or():
    char = input("Carácter: ")
    message = "Es vocal"

    if(char.lower() == "a" or char.lower() == "e" or char.lower() == "i" or char.lower() == "o" or char.lower() == "u"):
        message = message
    else:
        message = "No es vocal"
    return message

print(vocal_or())

# Este mismo ejercicio pero con un bucle for (iniciativa propia)

vocales = ("aeiou")
char = input("caracter: ")

def other():
    message = "Es vocal"
    for i in vocales:
        if char == i:
            return message
    return "No es vocal"
    
print(other())



# Ejercicio 8 

def meses():
    mes_nombre = " "
    try:
        mes_numero = int(input("número del 1 al 12: "))
    except:
        print("No es un valor válido")
    if(mes_numero == 1):
        mes_nombre = "Enero"
    elif mes_numero == 2:
        mes_nombre = "Febrero"
    elif mes_numero == 3:
        mes_nombre = "Marzo"
    elif mes_numero == 4:
        mes_nombre = "Abril"
    elif mes_numero == 5:
        mes_nombre = "Mayo"
    elif mes_numero == 6:
        mes_nombre = "Junio"
    elif mes_numero == 7:
        mes_nombre = "Julio"
    elif mes_numero == 8:
        mes_nombre = "Agosto"
    elif mes_numero == 9:
        mes_nombre = "Septiembre"
    elif mes_numero == 10:
        mes_nombre = "Octubre"
    elif mes_numero == 11:
        mes_nombre = "Noviembre"
    elif mes_numero == 12:
        mes_nombre = "Diciembre"
    else:
        mes_nombre = "ERROR, el valor no es válido"
    return mes_nombre

print(meses())


#Mismo ejercicio de antes pero con bucles for (menos noob)

#Gracias al chatGPT por hacerme unicamente esta lista, me daba mucha pereza escribir los meses yo
meses_nombre = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

char = int(input("mes: "))


if char <=12 and char >=1:
    for i in range(len((meses_nombre))):
            if char == char +1:
             print(meses_nombre[i])
else:
    print("ERROR, valor no válido")


import math

def raices():
    try:
        a = float(input("a: ")) 
        b = float(input("b: "))
        c = float(input("c: "))
        D = b**2 - 4*a*c
    except:
        print("Los valores no son válidos")

    
#Ejercicio 9 raices cuadradas

    if D > 0:
        operation = (-b + math.sqrt(D)) / (2*a) , (-b - math.sqrt(D)) / (2*a)
          
    elif D == 0:
        root1 = -b / (2*a)
        operation = (root1,)
    else:
        operation = "raíces imaginarias"

    return operation     

print(raices())



# Ejercicio 10 anio bisiesto si el año es superior a 1582 imprime si es bisiesto y si no, explica el pq no es bisiesto.

#from cuaderno_2_modularidad import es_bisiesto # por algún motivo no funciona se me importa todo el cuaderno xD

def es_bisiesto():
    anno = int(input("Introduce un año: "))
    if(anno > 1582):
        if (anno % 4 == 0 and anno % 100 != 0 ) or (anno % 400 == 0):
            return f"{anno} es bisiesto"
        else:
            return f"{anno} no es bisiesto"
    else:
        return f"{anno} no puede ser bisiesto dado que es menor que 1582 y seguía el calendario juliano"

print(es_bisiesto())


# Ejercicio 11 The ASCII program Este código ordena los valores de ascii

def ascii():
    
    while True:
     try: 
        primer = int(input("Introduce el primer valor: "))
        second = input("Introduce un carácter: ")
     
     except:
        print("No has introducido un valor válido")
     else:
         if (primer % 1 == 0) and (primer % primer == 0):
             print("Es primo")
         else:
             print("Es par")
        #Conversión a ASCII

         if(primer > ord(second)):
             return f"{primer} > {second}, los valores introducidos son: {chr(primer)} y {second}"
         else:
             return f"{second} > {primer}, los valores introducidos son: {second} y {chr(primer)}"
         
print(ascii())



# Ejercicio 12 Trigonometría del triángulo

import math
def trigonometria():
    operaciones = ("1.Seno \n 2.Coseno \n 3.Tangente \n 4.Cotangente \n 5.Secante \n 6.Cosecante \n")
    
    print(operaciones)

    while True:
     try: 
        valor = float(input("Introduce un valor: "))
        operacion = int(input("Introduce un valor del 1 al 6 para operar: "))
     except:
        print("no es un valor válido")
     else:
        if (operacion == 1):
            print(math.sin(valor))
        elif (operacion == 2):
            print(math.cos(valor))
        elif (operacion == 3):
            print(math.tan(valor))
        elif (operacion == 4):
            tangente = math.tan(valor)
            print( 1 / tangente)
        elif (operacion == 5):
            seno = math.sin(valor)
            print(1 / seno)
        elif (operacion == 6):
            coseno = math.cos(valor)
            print(1 / coseno)
        else:
            return 

print(trigonometria())

#Ejercicio 13 compañía
def factura():
    try:
        km = float(input("Kilómetros recorridos: "))
    except ValueError:
        return "Entrada no válida. Debe ingresar un valor numérico."
    
    if km <= 300:
        cantidad = 100
    elif km <= 1000:
        exceso = km - 300
        cantidad = 100 + exceso * 0.3
    else:
        exceso_300_1000 = 700 * 0.3
        exceso_mas_1000 = (km - 1000) * 0.2
        cantidad = 100 + exceso_300_1000 + exceso_mas_1000

    return f"***** Su FACTURA ES *****: \n {cantidad} EUR"

print(factura())

# Ejercicio 14 puntos para la beca de la unidad familiar

def beca():
    try:
        ingresos = float(input("Ingresos mensuales: "))
    except:
        print("Error, no es válido")
    else:
        if(ingresos >= 0 and ingresos < 1800):
            puntos = 4
        elif(ingresos >= 1800 and ingresos < 3500):
            puntos = 3
        elif(ingresos >= 3500 and ingresos < 5000):
            puntos = 2
        elif(ingresos >= 5000):
            puntos = 1
        else:
            puntos = "No es un valor válido"

        return puntos
    


print(beca())     


# Ejercicio 15 monomio

def imprimir_monomio():
    try:
        coeficiente = float(input("Ingrese el coeficiente: "))
        exponente = int(input("Ingrese el exponente (entero y positivo): "))
    except ValueError:
        print("Entrada no válida. El coeficiente debe ser un número real y el exponente un número entero positivo.")
        return

    monomio = ""

    # Verificar si el coeficiente es 0, si es 0, no se imprime nada.
    if coeficiente == 0:
        return

    # Verificar si el coeficiente es 1, si no es 1, imprimirlo.
    if coeficiente != 1:
        monomio += str(coeficiente)

    # Verificar si el exponente es mayor que 0, si es 0, no escribir "x".
    if exponente > 0:
        monomio += "x"

        # Verificar si el exponente es mayor que 1, si es 1, no escribir el exponente.
        if exponente > 1:
            monomio += f"^{exponente}"

    print(monomio)

# Ejemplo de uso:
imprimir_monomio()

"""






    

    

