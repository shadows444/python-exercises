import cv2

cam = cv2.VideoCapture(0)
img_counter = 0

while True:
    ret, frame = cam.read()
    if not ret:
        print("Failed to open it")
        break

    cv2.imshow("Camera", frame)
    k = cv2.waitKey(1)

    if k % 256 == 27 or cv2.getWindowProperty("Camera", cv2.WND_PROP_VISIBLE) < 1:
        print("Escape or window closed")
        break
     
    elif k % 256 == 32:
        img_name = "C:/Users/Blanquito/Desktop/capturas python/opencv_frame_{}.png".format(img_counter)
        cv2.imwrite(img_name, frame)
        print("Screenshot taken: {}".format(img_name))
        img_counter += 1
        
        print("Ruta de la captura: {}".format(img_name))
     
   

# Liberar la cámara al final
cam.release()
cv2.destroyAllWindows()   



     

