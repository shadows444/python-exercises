# Sesión post PL1 Estructura de Datos
   
# Ejercicio 1 Suma de listas
"""
lista = [1, 2, 3]
lista2 = [1, 2, 3]
resultado = []


for i in range(len(lista)):
    calculo = (lista[i] + lista2[i])
    resultado.append(calculo)
print(resultado)

"""


# Ejercicio 2 suma de listas distinta longitud

lista2 = [1, 2, 3]
lista = [1,2,3,9]
lista3 = []

if len(lista) < len(lista2):
   lista,lista2 = lista2,lista

for i in range(len(lista2)):
   lista3.append(lista[i] + lista2[i])
   

for i in range(len(lista2),len(lista)):
   lista3.append(lista[i])
   

print(lista3) 






   


        